from flask import Flask, render_template, request, redirect, url_for
import json
from datetime import datetime

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/order', methods=['POST'])
def order():
    data = request.form.to_dict()
    data['time'] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with open("orders.json", "a") as f:
        f.write(json.dumps(data) + "\n")
    return "Order Received!"

if __name__ == '__main__':
    app.run(debug=True)